const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1100, height: 800 } });

  // 1. Cadastro
  await page.goto('http://localhost:3000/index.html');
  await page.click('#toggle-link');
  await page.fill('#reg-nome', 'João Eletricista');
  await page.fill('#reg-empresa', 'João Eletricista MEI');
  await page.fill('#reg-email', 'joao.playwright@teste.com');
  await page.fill('#reg-telefone', '11988887777');
  await page.fill('#reg-senha', '123456');
  await page.check('#reg-termos');
  await page.click('#submit-register');
  await page.waitForURL('**/verificar-telefone.html');
  await page.goto('http://localhost:3000/dashboard.html');
  await page.screenshot({ path: 'shot-1-dashboard-vazio.png', fullPage: true });

  // 2. Criar um pacote
  await page.goto('http://localhost:3000/pacotes.html');
  await page.fill('#p-nome', 'Completo');
  await page.fill('#p-conteudo', 'Equipe de 2 pessoas, transporte e desmontagem/montagem');
  await page.fill('#p-preco', '1850');
  await page.check('#p-destaque');
  await page.click('text=Salvar modelo');
  await page.waitForTimeout(500);
  await page.screenshot({ path: 'shot-2-pacotes.png', fullPage: true });

  // 3. Criar orçamento em Modo Rápido, usando o pacote
  await page.goto('http://localhost:3000/novo-orcamento.html');
  await page.fill('#r-nome', 'Maria Residencial');
  await page.fill('#r-telefone', '11987654321');
  await page.fill('#r-servico', 'Mudança residencial');
  await page.fill('#r-valor', '1850');
  await page.selectOption('#r-pacote', { index: 1 });
  await page.click('#btn-gerar-rapido');
  await page.waitForSelector('text=Orçamento gerado!');
  await page.screenshot({ path: 'shot-3-modo-rapido.png', fullPage: true });

  const link = await page.getAttribute('#r-resultado a', 'href');
  console.log('LINK PUBLICO:', link);

  // 4. Abrir a página pública como se fosse o cliente (navegador comum)
  const clientPage = await browser.newPage({ viewport: { width: 420, height: 850 } });
  await clientPage.goto('http://localhost:3000' + link);
  await clientPage.waitForTimeout(500);
  await clientPage.mouse.wheel(0, 200); // simula rolagem = interação humana real
  await clientPage.waitForTimeout(800);
  await clientPage.screenshot({ path: 'shot-4-pagina-publica-cliente.png', fullPage: true });

  // 5. Cliente escolhe o pacote (agora obrigatório) e aceita
  await clientPage.check('input[name="pacote"]');
  await clientPage.click('text=Aceitar orçamento');
  await clientPage.waitForTimeout(400);
  await clientPage.screenshot({ path: 'shot-5-aprovado.png', fullPage: true });
  await clientPage.close();

  // 6. Voltar ao dashboard do prestador e conferir números atualizados
  await page.goto('http://localhost:3000/dashboard.html');
  await page.waitForTimeout(400);
  await page.screenshot({ path: 'shot-6-dashboard-apos-aprovacao.png', fullPage: true });

  // 7. Criar um SEGUNDO orçamento que fica pendente, para testar o Radar
  await page.goto('http://localhost:3000/novo-orcamento.html');
  await page.fill('#r-nome', 'Carlos Pendente');
  await page.fill('#r-telefone', '11911112222');
  await page.fill('#r-servico', 'Instalação elétrica');
  await page.fill('#r-valor', '600');
  await page.click('#btn-gerar-rapido');
  await page.waitForSelector('text=Orçamento gerado!');

  await page.goto('http://localhost:3000/radar.html');
  await page.waitForTimeout(300);
  await page.screenshot({ path: 'shot-7-radar.png', fullPage: true });

  await page.goto('http://localhost:3000/historico.html');
  await page.waitForTimeout(300);
  await page.screenshot({ path: 'shot-8-historico.png', fullPage: true });

  await browser.close();
  console.log('OK - testes visuais concluídos');
})();
