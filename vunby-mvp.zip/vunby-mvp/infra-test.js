const assert = require('assert');

async function post(path, body, cookies) {
  const res = await fetch(`http://localhost:3000${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(cookies ? { Cookie: cookies } : {}) },
    body: JSON.stringify(body || {}),
  });
  const setCookie = res.headers.get('set-cookie');
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data, setCookie };
}

function extractCookie(setCookieHeader) {
  if (!setCookieHeader) return null;
  return setCookieHeader.split(';')[0];
}

(async () => {
  console.log('=== TESTE 1: telefone só recebe trial uma vez, mesmo após excluir a conta ===');
  const TELEFONE = '11999990001';

  // Conta A: cadastra, verifica telefone, recebe trial.
  const regA = await post('/api/auth/register', {
    nome: 'Conta A', email: 'conta-a@teste.com', telefone: TELEFONE, senha: '123456', aceitouTermos: true,
  });
  assert.strictEqual(regA.status, 201, 'FALHA: cadastro da Conta A deveria retornar 201.');
  const cookieA = extractCookie(regA.setCookie);
  assert.ok(regA.data.codigoDev, 'FALHA: codigoDev deveria vir na resposta em modo dev.');

  const confirmA = await post('/api/auth/phone/confirmar', { codigo: regA.data.codigoDev }, cookieA);
  assert.strictEqual(confirmA.status, 200);
  assert.strictEqual(confirmA.data.trialConcedido, true, 'FALHA: Conta A deveria receber o trial (primeiro uso do telefone).');
  console.log('OK: Conta A recebeu o trial no primeiro uso do telefone.');

  // Exclui a Conta A.
  const delA = await post('/api/auth/excluir-conta', { senha: '123456' }, cookieA);
  assert.strictEqual(delA.status, 200, 'FALHA: exclusão da Conta A deveria funcionar.');
  console.log('OK: Conta A excluída com sucesso.');

  // Conta B: MESMO telefone, conta nova, mesma pessoa ou não — não importa,
  // a regra é sobre o telefone. Deve poder criar a conta (não bloqueia
  // cadastro), mas NÃO deve receber o trial de novo.
  const regB = await post('/api/auth/register', {
    nome: 'Conta B', email: 'conta-b@teste.com', telefone: TELEFONE, senha: '123456', aceitouTermos: true,
  });
  assert.strictEqual(regB.status, 201, 'FALHA: cadastro da Conta B (mesmo telefone) deveria ser permitido.');
  const cookieB = extractCookie(regB.setCookie);
  // Ponto de atenção: a resposta do cadastro NÃO deve revelar que o
  // telefone já foi usado antes por outra conta.
  assert.strictEqual(regB.data.trialConcedido, null, 'FALHA: cadastro não deveria antecipar o resultado do trial antes da verificação.');

  const confirmB = await post('/api/auth/phone/confirmar', { codigo: regB.data.codigoDev }, cookieB);
  assert.strictEqual(confirmB.status, 200);
  assert.strictEqual(confirmB.data.trialConcedido, false, 'FALHA CRÍTICA: Conta B recebeu trial de novo com telefone já usado — a exclusão da Conta A vazou o controle antifraude!');
  assert.ok(
    !/conta a|conta-a@teste\.com|id\s*\d/i.test(confirmB.data.mensagem),
    'FALHA: mensagem para Conta B não deveria citar dados da Conta A.'
  );
  console.log('OK: Conta B NÃO recebeu trial (telefone já usado) mesmo com a Conta A excluída.');
  console.log('OK: mensagem não revela qual conta usou o telefone antes.');

  console.log('\n=== TESTE 2: exclusão de conta realmente funciona (login para de funcionar) ===');
  const loginApósExcluir = await post('/api/auth/login', { email: 'conta-a@teste.com', senha: '123456' });
  assert.strictEqual(loginApósExcluir.status, 401, 'FALHA: login da Conta A excluída deveria falhar.');
  console.log('OK: login da Conta A excluída falha corretamente (401).');

  console.log('\n=== TESTE 3: recuperação de senha ===');
  const pedidoReset = await post('/api/auth/recuperar-senha', { email: 'conta-b@teste.com' });
  assert.strictEqual(pedidoReset.status, 200);
  assert.ok(pedidoReset.data.tokenDev, 'FALHA: tokenDev deveria vir na resposta em modo dev para conta existente.');
  console.log('OK: pedido de recuperação para e-mail existente gera token.');

  const pedidoResetInexistente = await post('/api/auth/recuperar-senha', { email: 'nao-existe@teste.com' });
  assert.strictEqual(pedidoResetInexistente.status, 200, 'FALHA: pedido para e-mail inexistente deveria responder 200 (não revelar se existe).');
  assert.strictEqual(pedidoResetInexistente.data.mensagem, pedidoReset.data.mensagem, 'FALHA: mensagem deveria ser idêntica exista ou não o e-mail (evitar enumeração).');
  assert.ok(!pedidoResetInexistente.data.tokenDev, 'FALHA: não deveria gerar token para e-mail que não existe.');
  console.log('OK: resposta idêntica para e-mail existente/inexistente (não revela existência de conta).');

  const redefinir = await post('/api/auth/redefinir-senha', { token: pedidoReset.data.tokenDev, novaSenha: 'novaSenha123' });
  assert.strictEqual(redefinir.status, 200, 'FALHA: redefinição de senha com token válido deveria funcionar.');
  console.log('OK: senha redefinida com token válido.');

  const loginComNovaSenha = await post('/api/auth/login', { email: 'conta-b@teste.com', senha: 'novaSenha123' });
  assert.strictEqual(loginComNovaSenha.status, 200, 'FALHA: login com a nova senha deveria funcionar.');
  console.log('OK: login funciona com a nova senha.');

  const reusarToken = await post('/api/auth/redefinir-senha', { token: pedidoReset.data.tokenDev, novaSenha: 'outraSenha456' });
  assert.strictEqual(reusarToken.status, 400, 'FALHA: token de reset já usado não deveria funcionar de novo.');
  console.log('OK: token de recuperação é de uso único.');

  console.log('\n=== TESTE 4: rate limiting em login ===');
  let bloqueado = false;
  for (let i = 0; i < 12; i++) {
    const tentativa = await post('/api/auth/login', { email: 'nao-existe-rl@teste.com', senha: 'errada' });
    if (tentativa.status === 429) {
      bloqueado = true;
      break;
    }
  }
  assert.ok(bloqueado, 'FALHA: rate limiting de login não bloqueou após várias tentativas.');
  console.log('OK: rate limiting bloqueia excesso de tentativas de login (429).');

  console.log('\n=== TESTE 5: nenhum usuário acessa dados de outra conta ===');
  const regC = await post('/api/auth/register', {
    nome: 'Conta C', email: 'conta-c@teste.com', telefone: '11999990002', senha: '123456', aceitouTermos: true,
  });
  const cookieC = extractCookie(regC.setCookie);
  const quoteC = await post('/api/quotes/rapido', { clienteNome: 'X', clienteTelefone: '11900000000', servico: 'Y', valor: 100 }, cookieC);
  const quoteIdC = quoteC.data.quote.id;

  // Conta B tenta acessar o orçamento da Conta C pelo id.
  const acessoIndevido = await fetch(`http://localhost:3000/api/quotes/${quoteIdC}`, { headers: { Cookie: cookieB } });
  assert.strictEqual(acessoIndevido.status, 404, 'FALHA CRÍTICA: Conta B conseguiu acessar orçamento de outra conta!');
  console.log('OK: Conta B não consegue acessar orçamento da Conta C (404, isolamento por conta preservado).');

  console.log('\n=== TESTE 6: cadastro sem aceitar termos é bloqueado ===');
  const semTermos = await post('/api/auth/register', {
    nome: 'Sem Termos', email: 'sem-termos@teste.com', telefone: '11999990003', senha: '123456', aceitouTermos: false,
  });
  assert.strictEqual(semTermos.status, 400, 'FALHA: cadastro sem aceitar termos deveria ser bloqueado.');
  console.log('OK: cadastro exige aceite dos Termos/Política.');

  console.log('\n=== TESTE 7: cadastro sem telefone é bloqueado ===');
  const semTelefone = await post('/api/auth/register', {
    nome: 'Sem Tel', email: 'sem-tel@teste.com', senha: '123456', aceitouTermos: true,
  });
  assert.strictEqual(semTelefone.status, 400, 'FALHA: cadastro sem telefone deveria ser bloqueado.');
  console.log('OK: cadastro exige telefone.');

  console.log('\n=== TESTE 8: rate limiting em cadastro ===');
  let bloqueadoCadastro = false;
  for (let i = 0; i < 12; i++) {
    const tentativa = await post('/api/auth/register', {
      nome: 'Spam', email: `spam-${i}@teste.com`, telefone: `1199999${String(1000 + i)}`, senha: '123456', aceitouTermos: true,
    });
    if (tentativa.status === 429) {
      bloqueadoCadastro = true;
      break;
    }
  }
  assert.ok(bloqueadoCadastro, 'FALHA: rate limiting de cadastro não bloqueou após várias tentativas.');
  console.log('OK: rate limiting bloqueia excesso de cadastros (429).');

  console.log('\n=== TESTE 9: rate limiting em recuperação de senha ===');
  let bloqueadoReset = false;
  for (let i = 0; i < 10; i++) {
    const tentativa = await post('/api/auth/recuperar-senha', { email: `qualquer-${i}@teste.com` });
    if (tentativa.status === 429) {
      bloqueadoReset = true;
      break;
    }
  }
  assert.ok(bloqueadoReset, 'FALHA: rate limiting de recuperação de senha não bloqueou após várias tentativas.');
  console.log('OK: rate limiting bloqueia excesso de pedidos de recuperação de senha (429).');

  console.log('\n=== TODOS OS TESTES DE INFRAESTRUTURA PASSARAM ===');
})().catch((err) => {
  console.error('FALHA NO TESTE:', err.message);
  process.exit(1);
});
