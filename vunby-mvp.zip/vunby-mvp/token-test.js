const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const BASE = 'http://localhost:3000';
const DB_FILE = path.join(__dirname, 'data', 'db.json');

async function post(p, body, cookie) {
  const res = await fetch(BASE + p, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
    body: JSON.stringify(body || {}),
  });
  const setCookie = res.headers.get('set-cookie');
  return { status: res.status, data: await res.json().catch(() => ({})), cookie: setCookie ? setCookie.split(';')[0] : null };
}

const readDb = () => JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
const isHex64 = (v) => typeof v === 'string' && /^[0-9a-f]{64}$/.test(v);

(async () => {
  // =====================================================================
  console.log('=== A. E-MAIL DUPLICADO ===');
  const EMAIL = 'dup@teste.com';
  const reg1 = await post('/api/auth/register', {
    nome: 'Original', email: EMAIL, telefone: '11988880001', senha: 'senhaOriginal', aceitouTermos: true,
  });
  assert.strictEqual(reg1.status, 201);
  const cookie1 = reg1.cookie;
  const codigo1 = reg1.data.codigoDev;

  const regDup = await post('/api/auth/register', {
    nome: 'Duplicada', email: EMAIL, telefone: '11988880002', senha: 'outraSenha123', aceitouTermos: true,
  });
  assert.strictEqual(regDup.status, 409, 'FALHA: cadastro duplicado deveria retornar 409.');
  assert.strictEqual(regDup.data.error, 'Este e-mail já está cadastrado.', 'FALHA: mensagem de e-mail duplicado diferente da definida.');
  console.log('OK: e-mail duplicado retorna 409 com a mensagem exata "Este e-mail já está cadastrado.".');

  assert.strictEqual((await post('/api/auth/login', { email: EMAIL, senha: 'senhaOriginal' })).status, 200);
  assert.strictEqual((await post('/api/auth/login', { email: EMAIL, senha: 'outraSenha123' })).status, 401, 'FALHA: a tentativa duplicada sobrescreveu/criou credencial.');
  assert.strictEqual(readDb().accounts.filter((a) => a.email === EMAIL).length, 1, 'FALHA: conta duplicada foi criada.');
  console.log('OK: nenhuma conta duplicada foi criada; a conta original continua intacta.');

  // Tela: a mensagem aparece para o usuário no cadastro.
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto(BASE + '/index.html');
  await page.click('#toggle-link');
  await page.fill('#reg-nome', 'Tentativa UI');
  await page.fill('#reg-email', EMAIL);
  await page.fill('#reg-telefone', '11988880009');
  await page.fill('#reg-senha', '123456');
  await page.check('#reg-termos');
  await page.click('#submit-register');
  await page.waitForFunction(() => document.getElementById('msg').textContent.length > 0);
  const msgTela = await page.textContent('#msg');
  assert.strictEqual(msgTela, 'Este e-mail já está cadastrado.', `FALHA: mensagem na tela foi "${msgTela}".`);
  assert.ok(page.url().includes('/index.html'), 'FALHA: a tela deveria permanecer no cadastro.');
  await browser.close();
  console.log('OK: a tela de cadastro exibe "Este e-mail já está cadastrado." e não avança.');

  // =====================================================================
  console.log('\n=== B. CÓDIGO DE TELEFONE: armazenado como hash e funcionando ===');
  const regRec = readDb().phoneVerifications.find((v) => v.accountId === readDb().accounts.find((a) => a.email === EMAIL).id);
  assert.ok(regRec, 'FALHA: registro de verificação não encontrado.');
  assert.ok(!('codigo' in regRec), 'FALHA: campo "codigo" em texto claro ainda existe no banco.');
  assert.ok(isHex64(regRec.codigoHash), 'FALHA: codigoHash ausente ou em formato inesperado.');
  assert.ok(Object.values(regRec).every((v) => v !== codigo1), 'FALHA: o código utilizável aparece em algum campo do registro.');
  console.log('OK: banco guarda só codigoHash (64 hex); nenhum campo contém o código utilizável.');

  // O hash guardado não pode servir como código.
  const usarHash = await post('/api/auth/phone/confirmar', { codigo: regRec.codigoHash }, cookie1);
  assert.strictEqual(usarHash.status, 400, 'FALHA: o hash armazenado foi aceito como código.');
  const errado = await post('/api/auth/phone/confirmar', { codigo: codigo1 === '000000' ? '111111' : '000000' }, cookie1);
  assert.strictEqual(errado.status, 400);
  assert.strictEqual(errado.data.error, 'Código inválido ou expirado.');
  console.log('OK: código errado e o próprio hash armazenado são rejeitados.');

  const certo = await post('/api/auth/phone/confirmar', { codigo: codigo1 }, cookie1);
  assert.strictEqual(certo.status, 200);
  assert.strictEqual(certo.data.telefoneVerificado, true);
  assert.strictEqual(certo.data.trialConcedido, true);
  assert.ok(readDb().phoneVerifications.find((v) => v.id === regRec.id).confirmadoEm, 'FALHA: código usado não foi marcado como consumido.');
  console.log('OK: código correto continua funcionando com hash; trial concedido; código marcado como usado.');

  // Reenvio: só o código mais recente vale; códigos não valem entre contas.
  const reg2 = await post('/api/auth/register', { nome: 'Dois', email: 'dois@teste.com', telefone: '11988880003', senha: '123456', aceitouTermos: true });
  const reenv = await post('/api/auth/phone/reenviar', {}, reg2.cookie);
  assert.strictEqual(reenv.status, 200);
  assert.notStrictEqual(reenv.data.codigoDev, reg2.data.codigoDev);
  const antigo = await post('/api/auth/phone/confirmar', { codigo: reg2.data.codigoDev }, reg2.cookie);
  assert.strictEqual(antigo.status, 400, 'FALHA: código antigo (substituído pelo reenvio) ainda foi aceito.');
  const reg3 = await post('/api/auth/register', { nome: 'Três', email: 'tres@teste.com', telefone: '11988880004', senha: '123456', aceitouTermos: true });
  const cruzado = await post('/api/auth/phone/confirmar', { codigo: reenv.data.codigoDev }, reg3.cookie);
  assert.strictEqual(cruzado.status, 400, 'FALHA: código de uma conta foi aceito em outra conta.');
  const novoOk = await post('/api/auth/phone/confirmar', { codigo: reenv.data.codigoDev }, reg2.cookie);
  assert.strictEqual(novoOk.status, 200, 'FALHA: código reenviado válido deveria funcionar.');
  console.log('OK: reenvio invalida o código anterior; código não vale em outra conta; código novo funciona.');

  // =====================================================================
  console.log('\n=== C. RECUPERAÇÃO DE SENHA: token armazenado como hash e funcionando ===');
  const pedido1 = await post('/api/auth/recuperar-senha', { email: EMAIL });
  const token1 = pedido1.data.tokenDev;
  assert.ok(token1);
  const dbTxt = fs.readFileSync(DB_FILE, 'utf8');
  assert.ok(!dbTxt.includes(token1), 'FALHA: o token utilizável está em texto claro no arquivo do banco.');
  const conta = readDb().accounts.find((a) => a.email === EMAIL);
  const recReset = readDb().passwordResets.filter((r) => r.accountId === conta.id).pop();
  assert.ok(!('token' in recReset), 'FALHA: campo "token" em texto claro ainda existe.');
  assert.ok(isHex64(recReset.tokenHash), 'FALHA: tokenHash ausente ou em formato inesperado.');
  console.log('OK: o token não aparece em lugar nenhum do banco; só tokenHash (64 hex).');

  const usarHashComoToken = await post('/api/auth/redefinir-senha', { token: recReset.tokenHash, novaSenha: 'hackeada123' });
  assert.strictEqual(usarHashComoToken.status, 400, 'FALHA: o hash armazenado foi aceito como token.');
  const tokenErrado = await post('/api/auth/redefinir-senha', { token: 'token-que-nao-existe', novaSenha: 'x123456' });
  assert.strictEqual(tokenErrado.status, 400);
  assert.strictEqual(tokenErrado.data.error, 'Link inválido ou expirado.');
  console.log('OK: token errado e o próprio hash armazenado são rejeitados.');

  const pedido2 = await post('/api/auth/recuperar-senha', { email: EMAIL });
  const token2 = pedido2.data.tokenDev;
  assert.notStrictEqual(token1, token2);

  const redef = await post('/api/auth/redefinir-senha', { token: token1, novaSenha: 'senhaNova123' });
  assert.strictEqual(redef.status, 200, 'FALHA: token válido com hash deveria redefinir a senha.');
  assert.strictEqual((await post('/api/auth/login', { email: EMAIL, senha: 'senhaNova123' })).status, 200);
  assert.strictEqual((await post('/api/auth/login', { email: EMAIL, senha: 'senhaOriginal' })).status, 401);
  console.log('OK: redefinição com token (hash) funciona; senha nova vale e a antiga não.');

  const reuso = await post('/api/auth/redefinir-senha', { token: token1, novaSenha: 'outra456789' });
  assert.strictEqual(reuso.status, 400, 'FALHA: token já usado foi aceito de novo.');
  const irmao = await post('/api/auth/redefinir-senha', { token: token2, novaSenha: 'outra456789' });
  assert.strictEqual(irmao.status, 400, 'FALHA: outro link pendente da mesma conta continuou válido após a troca de senha.');
  console.log('OK: uso único — token usado e links pendentes da mesma conta ficam inválidos.');

  console.log('\n=== TODOS OS TESTES DE E-MAIL DUPLICADO / HASH PASSARAM ===');
})().catch((err) => {
  console.error('FALHA NO TESTE:', err.message);
  process.exit(1);
});
