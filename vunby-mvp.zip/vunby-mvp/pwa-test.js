const { chromium } = require('playwright');
const assert = require('assert');

(async () => {
  const browser = await chromium.launch();

  // ---------- 1. Manifest e Service Worker nas páginas do prestador ----------
  const page = await browser.newPage({ viewport: { width: 1000, height: 800 } });
  const consoleErrors = [];
  page.on('pageerror', (err) => consoleErrors.push(err.message));

  await page.goto('http://localhost:3000/index.html');
  await page.click('#toggle-link');
  await page.fill('#reg-nome', 'Teste PWA');
  await page.fill('#reg-email', 'pwa@teste.com');
  await page.fill('#reg-telefone', '11966665555');
  await page.fill('#reg-senha', '123456');
  await page.check('#reg-termos');
  await page.click('#submit-register');
  await page.waitForURL('**/verificar-telefone.html');
  await page.goto('http://localhost:3000/dashboard.html');

  const manifestHref = await page.getAttribute('link[rel="manifest"]', 'href');
  assert.strictEqual(manifestHref, 'manifest.json', 'FALHA: dashboard.html sem link de manifest.');
  console.log('OK: dashboard.html referencia o manifest.');

  // Espera o Service Worker assumir controle
  const swState = await page.evaluate(async () => {
    const reg = await navigator.serviceWorker.getRegistration();
    return reg ? reg.active?.state || 'registrado' : null;
  });
  assert.ok(swState, 'FALHA: Service Worker não foi registrado em dashboard.html.');
  console.log('OK: Service Worker registrado em dashboard.html (estado: ' + swState + ').');

  assert.strictEqual(consoleErrors.length, 0, 'FALHA: erros de JS no console: ' + consoleErrors.join('; '));
  console.log('OK: nenhum erro de JavaScript ao carregar com o Service Worker.');

  // ---------- 2. Página pública NÃO deve ter manifest nem registrar SW ----------
  const publicPage = await browser.newPage();
  await publicPage.goto('http://localhost:3000/novo-orcamento.html'); // reaproveita sessão? não, novo contexto sem cookie
  // usa o contexto autenticado (page) para gerar um orçamento e pegar o link
  await page.goto('http://localhost:3000/novo-orcamento.html');
  await page.fill('#r-nome', 'Cliente PWA');
  await page.fill('#r-telefone', '11955554444');
  await page.fill('#r-servico', 'Teste');
  await page.fill('#r-valor', '200');
  await page.click('#btn-gerar-rapido');
  await page.waitForSelector('text=Orçamento gerado!');
  const link = await page.getAttribute('#r-resultado a', 'href');

  const publicManifest = await publicPage.evaluate(() => document.querySelector('link[rel="manifest"]'));
  await publicPage.goto('http://localhost:3000' + link);
  const temManifestPublico = await publicPage.$('link[rel="manifest"]');
  assert.strictEqual(temManifestPublico, null, 'FALHA: a página pública do cliente NÃO deveria ter link de manifest (cliente não precisa instalar).');
  console.log('OK: página pública do cliente não referencia manifest (não é instalável).');

  const swNaPaginaPublica = await publicPage.evaluate(async () => {
    const reg = await navigator.serviceWorker.getRegistration();
    return !!reg;
  });
  // Pode ser `true` só se um SW de escopo "/" já tiver sido registrado
  // ANTES neste mesmo navegador (pelo próprio prestador) — mas o registro
  // em si nunca é disparado pelo código de orcamento.html.
  const registrouAPartirDaPaginaPublica = await publicPage.evaluate(() =>
    document.querySelector('script[src="app.js"]') !== null
  );
  assert.strictEqual(registrouAPartirDaPaginaPublica, false, 'FALHA: página pública carrega app.js, que registraria o Service Worker.');
  console.log('OK: página pública não carrega o script que registra o Service Worker.');
  await publicPage.close();

  // ---------- 3. Responsividade mobile (375px, iPhone SE) ----------
  const mobile = await browser.newPage({ viewport: { width: 375, height: 667 } });
  await mobile.goto('http://localhost:3000/index.html');
  await mobile.fill('#login-email', 'pwa@teste.com');
  await mobile.fill('#login-senha', '123456');
  await mobile.click('#submit-login');
  await mobile.waitForURL('**/dashboard.html');

  const larguraDocumento = await mobile.evaluate(() => document.documentElement.scrollWidth);
  const larguraJanela = await mobile.evaluate(() => window.innerWidth);
  assert.ok(larguraDocumento <= larguraJanela + 1, `FALHA: overflow horizontal em mobile (documento=${larguraDocumento}px, janela=${larguraJanela}px).`);
  console.log('OK: sem overflow horizontal no Dashboard em 375px.');
  await mobile.screenshot({ path: 'shot-pwa-mobile-dashboard.png', fullPage: true });

  await mobile.goto('http://localhost:3000/historico.html');
  await mobile.waitForTimeout(200);
  const larguraHistorico = await mobile.evaluate(() => document.documentElement.scrollWidth);
  assert.ok(larguraHistorico <= larguraJanela + 1, `FALHA: overflow horizontal no Histórico em mobile (${larguraHistorico}px).`);
  console.log('OK: sem overflow horizontal no Histórico em 375px (tabela rola dentro do card).');
  await mobile.screenshot({ path: 'shot-pwa-mobile-historico.png', fullPage: true });

  await mobile.goto('http://localhost:3000' + link);
  await mobile.screenshot({ path: 'shot-pwa-mobile-publico.png', fullPage: true });

  await browser.close();
  console.log('\n=== TODOS OS TESTES DE PWA/RESPONSIVIDADE PASSARAM ===');
})().catch((err) => {
  console.error('FALHA NO TESTE:', err.message);
  process.exit(1);
});
