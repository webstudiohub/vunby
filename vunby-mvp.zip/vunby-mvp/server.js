'use strict';
const path = require('path');
const { Router, createServer } = require('./lib/http');

const router = new Router();

require('./routes/auth').register(router);
require('./routes/clients').register(router);
require('./routes/quotes').register(router);
require('./routes/public').register(router);
require('./routes/followups').register(router);
require('./routes/radar').register(router);
require('./routes/dashboard').register(router);

const PORT = process.env.PORT || 3000;
const server = createServer(router, path.join(__dirname, 'public'));

server.listen(PORT, () => {
  console.log(`VUNBY MVP rodando em http://localhost:${PORT}`);
});

module.exports = server;
