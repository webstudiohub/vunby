async function api(path, options = {}) {
  const res = await fetch(path, {
    method: options.method || 'GET',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Erro na requisição.');
  return data;
}

/**
 * Escapa qualquer texto antes de injetar em innerHTML. OBRIGATÓRIO em todo
 * dado que veio do usuário (nome de cliente, serviço, observações, conteúdo
 * de pacote, mensagens de follow-up etc.) — nunca confiar que texto livre
 * digitado por alguém é seguro para virar HTML.
 */
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function brl(v) {
  return (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function badgeClass(status) {
  return 'badge badge-' + status.replace(' ', '-');
}

async function requireSession() {
  try {
    return await api('/api/auth/me');
  } catch {
    window.location.href = '/index.html';
    return null;
  }
}

function topbar(active) {
  const items = [
    ['dashboard.html', 'Dashboard'],
    ['novo-orcamento.html', 'Novo Orçamento'],
    ['radar.html', 'Radar de Vendas'],
    ['historico.html', 'Histórico'],
    ['pacotes.html', 'Pacotes'],
    ['conta.html', 'Conta'],
  ];
  const links = items
    .map(([href, label]) => `<a href="${href}" style="${active === href ? 'text-decoration:underline;' : ''}">${label}</a>`)
    .join('');
  return `
    <div class="topbar">
      <div class="brand">VUNBY</div>
      <nav>${links}<a href="#" id="logout-link">Sair</a></nav>
    </div>`;
}

function wireLogout() {
  const el = document.getElementById('logout-link');
  if (el) {
    el.addEventListener('click', async (e) => {
      e.preventDefault();
      await api('/api/auth/logout', { method: 'POST' });
      window.location.href = '/index.html';
    });
  }
}

/**
 * Registra o Service Worker (base do PWA). Só é chamado pelas páginas do
 * PRESTADOR, porque só elas incluem app.js — a página pública do cliente
 * (orcamento.html) não inclui este arquivo, então nunca registra nada. O
 * cliente não precisa instalar a PWA para ver/aceitar/recusar orçamento.
 */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => {
      console.warn('Service Worker não registrado:', err);
    });
  });
}
