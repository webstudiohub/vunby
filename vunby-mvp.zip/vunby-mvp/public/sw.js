'use strict';
/**
 * Service Worker da VUNBY.
 *
 * Regra que não pode quebrar: dado de negócio (status de orçamento, valor
 * em aberto, Radar, aprovação/recusa) NUNCA pode vir de cache — isso
 * contradiria a spec inteira (Seção 9, Seção 14). Por isso este SW só
 * cacheia o "casco" estático do app (HTML/CSS/JS/ícones) e deixa toda
 * chamada de API (/api/...) passar direto pela rede, sem interceptar.
 *
 * Este SW só é registrado nas páginas do PRESTADOR (ver app.js). A página
 * pública do orçamento (orcamento.html) não registra nada — o cliente não
 * precisa instalar a PWA para ver/aceitar/recusar um orçamento.
 */

const CACHE_VERSION = 'vunby-shell-v1';

// Casco estático das telas do prestador — não inclui orcamento.html (a
// página pública do cliente) nem nenhuma rota /api/.
const SHELL_FILES = [
  '/index.html',
  '/dashboard.html',
  '/novo-orcamento.html',
  '/radar.html',
  '/historico.html',
  '/pacotes.html',
  '/conta.html',
  '/verificar-telefone.html',
  '/orcamento-detalhe.html',
  '/style.css',
  '/app.js',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(SHELL_FILES)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Regra inegociável: nada sob /api/ passa pelo cache — sempre rede.
  // Não chamar respondWith aqui equivale a deixar o navegador buscar
  // normalmente, sem o Service Worker no meio do caminho.
  if (url.pathname.startsWith('/api/')) {
    return;
  }

  // Só cuidamos de requisições do próprio app (GET, mesma origem).
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) {
    return;
  }

  const isNavegacao = event.request.mode === 'navigate';

  if (isNavegacao) {
    // HTML: network-first. Prioriza sempre a versão mais nova quando
    // online; cache só entra como último recurso (offline).
    event.respondWith(
      fetch(event.request)
        .then((resp) => {
          const copy = resp.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, copy));
          return resp;
        })
        .catch(() => caches.match(event.request).then((cached) => cached || caches.match('/dashboard.html')))
    );
    return;
  }

  // CSS/JS/ícones: cache-first (mudam pouco, prioriza velocidade),
  // com atualização silenciosa do cache em segundo plano.
  event.respondWith(
    caches.match(event.request).then((cached) => {
      const network = fetch(event.request)
        .then((resp) => {
          const copy = resp.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, copy));
          return resp;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});
