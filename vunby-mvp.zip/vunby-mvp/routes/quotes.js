'use strict';
const { json } = require('../lib/http');
const store = require('../lib/db');
const { requireAuth } = require('./auth');
const { generatePublicToken } = require('../lib/tokens');
const { serializeQuote } = require('../lib/serialize');
const cfg = require('../lib/config');
const { requireNonEmptyString, parsePositiveNumber, parsePositiveInteger, parseNonNegativeNumber } = require('../lib/validate');

function logEvent(quoteId, tipo, metadata) {
  const db = store.db();
  db.events.push({
    id: store.nextId('events'),
    quoteId,
    tipo,
    timestamp: Date.now(),
    metadata: metadata || null,
  });
}

/** Copia um Package Template para um snapshot congelado (Seção 6). */
function snapshotPackage(template, quoteId) {
  const db = store.db();
  const pkg = {
    id: store.nextId('quotePackages'),
    quoteId,
    templateOrigemId: template.id, // só histórico, sem dependência funcional
    nome: template.nome,
    conteudo: template.conteudo,
    preco: template.preco,
    destaque: template.destaque,
  };
  db.quotePackages.push(pkg);
  return pkg;
}

function findOrCreateClient(accountId, nome, telefone) {
  const db = store.db();
  let client = db.clients.find((c) => c.accountId === accountId && c.telefone === telefone);
  if (!client) {
    client = {
      id: store.nextId('clients'),
      accountId,
      nome,
      telefone,
      email: null,
      endereco: null,
      createdAt: Date.now(),
    };
    db.clients.push(client);
  }
  return client;
}

function register(router) {
  // ---------- Modo Rápido (Seção 5) ----------
  router.post('/api/quotes/rapido', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const { clienteNome, clienteTelefone, servico, valor, observacao, packageTemplateId } = req.body || {};
    if (!clienteNome || !clienteTelefone || !servico || valor == null) {
      return json(res, 400, { error: 'Nome do cliente, telefone, serviço e valor são obrigatórios.' });
    }
    requireNonEmptyString(clienteNome, 'Nome do cliente');
    requireNonEmptyString(clienteTelefone, 'Telefone/WhatsApp');
    requireNonEmptyString(servico, 'Serviço');
    const valorNumerico = parsePositiveNumber(valor, 'Valor');

    const db = store.db();
    const client = findOrCreateClient(session.accountId, clienteNome, clienteTelefone);

    const quote = {
      id: store.nextId('quotes'),
      accountId: session.accountId,
      clientId: client.id,
      servico,
      valor: valorNumerico,
      validade: null, // Modo Rápido não exige validade — pode ser definida na revisão futura
      observacoes: observacao || null,
      condicoes: null,
      decidedStatus: null, // null | 'Aprovado' | 'Recusado'
      publicToken: generatePublicToken(),
      createdAt: Date.now(),
      viewedAt: null,
      decidedAt: null,
      quotePackageId: null,
    };
    db.quotes.push(quote);

    if (packageTemplateId) {
      const tpl = db.packageTemplates.find((p) => p.id === Number(packageTemplateId) && p.accountId === session.accountId);
      if (tpl) snapshotPackage(tpl, quote.id);
    }

    store.save();
    logEvent(quote.id, 'criado_modo_rapido');

    const link = `/orcamento.html?token=${quote.publicToken}`;
    const linkAbsoluto = `${cfg.BASE_URL}${link}`;
    const whatsappTexto = encodeURIComponent(
      `Olá, ${client.nome}! Seu orçamento de ${servico} está pronto: R$ ${valorNumerico.toFixed(2)}. Veja os detalhes aqui: ${linkAbsoluto}`
    );
    const whatsappLink = `https://wa.me/${client.telefone.replace(/\D/g, '')}?text=${whatsappTexto}`;

    json(res, 201, { quote: serializeQuote(quote), link, whatsappLink });
  });

  // ---------- Orçamento Completo (Seção 5) ----------
  router.post('/api/quotes/completo', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const { clienteId, clienteNome, clienteTelefone, itens, packageTemplateIds, validade, observacoes, condicoes } = req.body || {};

    const db = store.db();
    let client;
    if (clienteId) {
      client = db.clients.find((c) => c.id === Number(clienteId) && c.accountId === session.accountId);
      if (!client) return json(res, 400, { error: 'Cliente não encontrado.' });
    } else {
      if (!clienteNome || !clienteTelefone) return json(res, 400, { error: 'Informe um cliente existente ou nome + telefone de um novo cliente.' });
      client = findOrCreateClient(session.accountId, clienteNome, clienteTelefone);
    }

    if (!Array.isArray(itens) || itens.length === 0) {
      return json(res, 400, { error: 'Inclua ao menos um item no orçamento completo.' });
    }

    // Ponto 6: valida cada item antes de confiar em qualquer número vindo
    // do cliente HTTP — não basta o <input type="number"> do formulário.
    const itensValidados = itens.map((it, idx) => {
      const descricao = requireNonEmptyString(it.descricao, `Descrição do item ${idx + 1}`);
      const quantidade = parsePositiveInteger(it.quantidade, `Quantidade do item ${idx + 1}`, { defaultValue: 1 });
      const valorUnitario = parseNonNegativeNumber(it.valorUnitario, `Valor unitário do item ${idx + 1}`);
      return { descricao, quantidade, valorUnitario, subtotal: quantidade * valorUnitario };
    });

    if (validade) {
      if (Number.isNaN(Date.parse(validade))) {
        return json(res, 400, { error: 'Data de validade inválida.' });
      }
    }

    const valorTotal = itensValidados.reduce((sum, it) => sum + it.subtotal, 0);

    const quote = {
      id: store.nextId('quotes'),
      accountId: session.accountId,
      clientId: client.id,
      servico: itensValidados[0].descricao,
      valor: valorTotal,
      validade: validade || null,
      observacoes: observacoes || null,
      condicoes: condicoes || null,
      decidedStatus: null,
      publicToken: generatePublicToken(),
      createdAt: Date.now(),
      viewedAt: null,
      decidedAt: null,
      quotePackageId: null,
    };
    db.quotes.push(quote);

    itensValidados.forEach((it) => {
      db.quoteItems.push({
        id: store.nextId('quoteItems'),
        quoteId: quote.id,
        descricao: it.descricao,
        quantidade: it.quantidade,
        valorUnitario: it.valorUnitario,
        subtotal: it.subtotal,
      });
    });

    (packageTemplateIds || []).forEach((tid) => {
      const tpl = db.packageTemplates.find((p) => p.id === Number(tid) && p.accountId === session.accountId);
      if (tpl) snapshotPackage(tpl, quote.id);
    });

    store.save();
    logEvent(quote.id, 'criado_completo');

    json(res, 201, { quote: serializeQuote(quote), link: `/orcamento.html?token=${quote.publicToken}` });
  });

  // ---------- Listagem / Histórico ----------
  router.get('/api/quotes', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const list = db.quotes
      .filter((q) => q.accountId === session.accountId)
      .sort((a, b) => b.createdAt - a.createdAt)
      .map((q) => {
        const client = db.clients.find((c) => c.id === q.clientId);
        return { ...serializeQuote(q), clienteNome: client ? client.nome : '—', clienteTelefone: client ? client.telefone : null };
      });
    json(res, 200, list);
  });

  router.get('/api/quotes/:id', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const quote = db.quotes.find((q) => q.id === Number(req.params.id) && q.accountId === session.accountId);
    if (!quote) return json(res, 404, { error: 'Orçamento não encontrado.' });
    const client = db.clients.find((c) => c.id === quote.clientId);
    const items = db.quoteItems.filter((i) => i.quoteId === quote.id);
    const packages = db.quotePackages.filter((p) => p.quoteId === quote.id);
    const followUps = db.followUps.filter((f) => f.quoteId === quote.id).sort((a, b) => b.createdAt - a.createdAt);
    const events = db.events.filter((e) => e.quoteId === quote.id).sort((a, b) => b.timestamp - a.timestamp);
    json(res, 200, { ...serializeQuote(quote), cliente: client, itens: items, pacotes: packages, followUps, eventos: events });
  });
}

module.exports = { register, logEvent, snapshotPackage };
