'use strict';
const { json } = require('../lib/http');
const store = require('../lib/db');
const { requireAuth } = require('./auth');
const { serializeQuote } = require('../lib/serialize');
const { VALOR_EM_ABERTO_STATUSES } = require('../lib/status');

function register(router) {
  router.get('/api/dashboard', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const now = Date.now();
    const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime();

    const quotes = db.quotes.filter((q) => q.accountId === session.accountId);
    const serialized = quotes.map((q) => serializeQuote(q, now));

    // Seção 14 — regra fixa: soma Enviado + Visualizado + Sem resposta,
    // independentemente de precisaFollowUp ou de estar vencido.
    const valorEmAberto = serialized
      .filter((s) => VALOR_EM_ABERTO_STATUSES.includes(s.status))
      .reduce((sum, s) => sum + s.valor, 0);

    const faturamentoMes = quotes
      .filter((q) => q.decidedStatus === 'Aprovado' && q.decidedAt >= startOfMonth)
      .reduce((sum, q) => {
        if (q.quotePackageId) {
          const pkg = db.quotePackages.find((p) => p.id === q.quotePackageId);
          return sum + (pkg ? pkg.preco : q.valor);
        }
        return sum + q.valor;
      }, 0);

    const contagemPorStatus = { Enviado: 0, Visualizado: 0, 'Sem resposta': 0, Aprovado: 0, Recusado: 0 };
    serialized.forEach((s) => (contagemPorStatus[s.status] = (contagemPorStatus[s.status] || 0) + 1));

    const recentes = quotes
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 8)
      .map((q) => {
        const s = serializeQuote(q, now);
        const client = db.clients.find((c) => c.id === q.clientId);
        return { id: q.id, clienteNome: client ? client.nome : '—', servico: q.servico, valor: q.valor, status: s.status, precisaFollowUp: s.precisaFollowUp };
      });

    json(res, 200, { valorEmAberto, faturamentoMes, contagemPorStatus, recentes, totalOrcamentos: quotes.length });
  });
}

module.exports = { register };
