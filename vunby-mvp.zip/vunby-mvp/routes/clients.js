'use strict';
const { json } = require('../lib/http');
const store = require('../lib/db');
const { requireAuth } = require('./auth');
const { requireNonEmptyString, parsePositiveNumber } = require('../lib/validate');

function register(router) {
  // ---------- Clientes ----------
  router.get('/api/clients', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    json(res, 200, db.clients.filter((c) => c.accountId === session.accountId));
  });

  router.post('/api/clients', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const { nome, telefone, email, endereco } = req.body || {};
    if (!nome || !telefone) return json(res, 400, { error: 'Nome e telefone são obrigatórios.' });
    requireNonEmptyString(nome, 'Nome');
    requireNonEmptyString(telefone, 'Telefone');
    const db = store.db();
    const client = {
      id: store.nextId('clients'),
      accountId: session.accountId,
      nome,
      telefone,
      email: email || null,
      endereco: endereco || null,
      createdAt: Date.now(),
    };
    db.clients.push(client);
    store.save();
    json(res, 201, client);
  });

  // ---------- Modelos de Pacote (reutilizáveis) ----------
  router.get('/api/packages', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    json(res, 200, db.packageTemplates.filter((p) => p.accountId === session.accountId));
  });

  router.post('/api/packages', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const { nome, conteudo, preco, destaque } = req.body || {};
    if (!nome || preco == null) return json(res, 400, { error: 'Nome e preço são obrigatórios.' });
    requireNonEmptyString(nome, 'Nome do pacote');
    const precoValidado = parsePositiveNumber(preco, 'Preço');
    const db = store.db();
    const tpl = {
      id: store.nextId('packageTemplates'),
      accountId: session.accountId,
      nome,
      conteudo: conteudo || '',
      preco: precoValidado,
      destaque: !!destaque,
      createdAt: Date.now(),
    };
    db.packageTemplates.push(tpl);
    store.save();
    json(res, 201, tpl);
  });

  router.post('/api/packages/:id/editar', (req, res) => {
    // POST em vez de PUT para manter o roteador simples — semântica de edição.
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const tpl = db.packageTemplates.find((p) => p.id === Number(req.params.id) && p.accountId === session.accountId);
    if (!tpl) return json(res, 404, { error: 'Modelo não encontrado.' });
    const { nome, conteudo, preco, destaque } = req.body || {};
    if (nome != null) tpl.nome = requireNonEmptyString(nome, 'Nome do pacote');
    if (conteudo != null) tpl.conteudo = conteudo;
    if (preco != null) tpl.preco = parsePositiveNumber(preco, 'Preço');
    if (destaque != null) tpl.destaque = !!destaque;
    // Importante (Seção 6): esta edição NUNCA altera Quote Packages já
    // copiados para orçamentos existentes — eles vivem em outra tabela.
    store.save();
    json(res, 200, tpl);
  });
}

module.exports = { register };
