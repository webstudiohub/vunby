'use strict';
const { json } = require('../lib/http');
const store = require('../lib/db');
const { requireAuth } = require('./auth');
const { serializeQuote } = require('../lib/serialize');
const { VALOR_EM_ABERTO_STATUSES } = require('../lib/status');

function register(router) {
  router.get('/api/radar', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const now = Date.now();

    const itens = db.quotes
      .filter((q) => q.accountId === session.accountId)
      .map((q) => serializeQuote(q, now))
      .filter((s) => VALOR_EM_ABERTO_STATUSES.includes(s.status)) // Aprovado/Recusado nunca aparecem aqui
      .map((s) => {
        const q = db.quotes.find((x) => x.id === s.id);
        const client = db.clients.find((c) => c.id === q.clientId);
        let sinal;
        let acaoSugerida;
        if (s.status === 'Enviado') {
          sinal = 'Ainda não visualizado';
          acaoSugerida = 'Aguardar ou confirmar se o link chegou ao cliente.';
        } else if (s.precisaFollowUp) {
          sinal = s.status === 'Visualizado' ? 'Visualizado, sem resposta' : 'Sem resposta';
          acaoSugerida = 'Considere enviar um follow-up.';
        } else {
          sinal = s.status === 'Visualizado' ? 'Visualizado recentemente' : 'Sem resposta (dentro do prazo de espera)';
          acaoSugerida = 'Nenhuma ação necessária agora.';
        }
        return {
          ...s,
          clienteNome: client ? client.nome : '—',
          sinal,
          acaoSugerida,
        };
      })
      // prioriza quem precisa de follow-up, depois o mais antigo primeiro
      .sort((a, b) => (b.precisaFollowUp - a.precisaFollowUp) || (a.createdAt - b.createdAt));

    json(res, 200, itens);
  });
}

module.exports = { register };
