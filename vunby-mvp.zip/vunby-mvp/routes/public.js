'use strict';
const { json } = require('../lib/http');
const store = require('../lib/db');
const status = require('../lib/status');
const cfg = require('../lib/config');
const { serializeQuote } = require('../lib/serialize');
const { logEvent } = require('./quotes');

// Defesa extra (Seção 9): além de exigir o evento disparado por JS após o
// carregamento, descartamos de cara User-Agents já conhecidos como
// crawlers de prévia — não é a defesa principal, é uma camada a mais.
const BOT_USER_AGENT_PATTERNS = [
  /whatsapp/i,
  /facebookexternalhit/i,
  /facebot/i,
  /twitterbot/i,
  /slackbot/i,
  /telegrambot/i,
  /discordbot/i,
  /linkedinbot/i,
  /googlebot/i,
  /bingbot/i,
  /bot\b/i,
  /crawler/i,
  /spider/i,
  /preview/i,
];

function isKnownBotUserAgent(ua) {
  if (!ua) return true; // sem user-agent nenhum: trata com desconfiança
  return BOT_USER_AGENT_PATTERNS.some((re) => re.test(ua));
}

function findByToken(token) {
  const db = store.db();
  return db.quotes.find((q) => q.publicToken === token);
}

function register(router) {
  // Dados públicos do orçamento — nunca expõe o ID interno, só o necessário.
  router.get('/api/public/quotes/:token', (req, res) => {
    const quote = findByToken(req.params.token);
    if (!quote) return json(res, 404, { error: 'Orçamento não encontrado.' });
    const db = store.db();
    const client = db.clients.find((c) => c.id === quote.clientId);
    const account = db.accounts.find((a) => a.id === quote.accountId);
    const items = db.quoteItems.filter((i) => i.quoteId === quote.id);
    const packages = db.quotePackages.filter((p) => p.quoteId === quote.id);
    const s = serializeQuote(quote);

    json(res, 200, {
      servico: quote.servico,
      valor: quote.valor,
      validade: quote.validade,
      observacoes: quote.observacoes,
      condicoes: quote.condicoes,
      status: s.status,
      expirado: s.expirado,
      decidido: quote.decidedStatus,
      itens: items.map(({ descricao, quantidade, valorUnitario, subtotal }) => ({ descricao, quantidade, valorUnitario, subtotal })),
      pacotes: packages.map(({ id, nome, conteudo, preco, destaque }) => ({ id, nome, conteudo, preco, destaque })),
      prestadorNome: account ? account.empresa || account.nome : 'Prestador',
      clienteNome: client ? client.nome : null,
      // "token" só reaparece aqui porque o próprio front precisa dele nas
      // próximas chamadas (view/decide) — nunca expomos quote.id.
      token: quote.publicToken,
    });
  });

  // Rastreamento de visualização humana (Seção 9 — ponto crítico).
  //
  // IMPORTANTE: isto é uma HEURÍSTICA, não uma garantia absoluta. Ela reduz
  // drasticamente falsos positivos de crawlers de prévia comuns (WhatsApp,
  // Facebook, Slack, Telegram etc., que tipicamente nem executam este
  // JavaScript), mas não prova de forma criptográfica que um humano estava
  // olhando a tela. Um navegador automatizado sofisticado que execute JS e
  // simule tempo de permanência/rolagem pode, em tese, escapar do filtro.
  // Isso é uma limitação conhecida e aceita pela spec v1.1 (Seção 9) — não
  // existe solução 100% infalível sem adicionar fricção ao cliente (como um
  // clique de confirmação), o que foi decidido não fazer.
  //
  // O front só chama esta rota depois de VISUALIZACAO_TEMPO_MINIMO_MS de
  // página aberta OU de uma interação real (ver public/orcamento.html).
  router.post('/api/public/quotes/:token/view', (req, res) => {
    const quote = findByToken(req.params.token);
    if (!quote) return json(res, 404, { error: 'Orçamento não encontrado.' });

    const ua = req.headers['user-agent'];
    const { tempoNaPaginaMs, interagiu } = req.body || {};
    const sinalValido = interagiu === true || (Number(tempoNaPaginaMs) || 0) >= cfg.VISUALIZACAO_TEMPO_MINIMO_MS;

    if (isKnownBotUserAgent(ua) || !sinalValido) {
      // Não é erro para o chamador — só não registra visualização.
      logEvent(quote.id, 'visualizacao_ignorada_possivel_bot', { ua, tempoNaPaginaMs, interagiu });
      return json(res, 200, { registrado: false });
    }

    if (!quote.viewedAt) {
      quote.viewedAt = Date.now();
      store.save();
      // heuristica:true no metadata deixa explícito, para quem auditar o
      // histórico depois, que este evento é uma inferência e não um fato
      // comprovado — nunca tratar "viewedAt" como certeza absoluta.
      logEvent(quote.id, 'visualizado', { tempoNaPaginaMs, interagiu, heuristica: true });
    }
    json(res, 200, { registrado: true });
  });

  // Aceitar / Recusar (bloqueado se vencido ou já decidido).
  router.post('/api/public/quotes/:token/decidir', (req, res) => {
    const quote = findByToken(req.params.token);
    if (!quote) return json(res, 404, { error: 'Orçamento não encontrado.' });

    if (quote.decidedStatus) {
      return json(res, 409, { error: 'Este orçamento já foi respondido.' });
    }
    if (status.isExpired(quote)) {
      return json(res, 409, { error: 'Este orçamento expirou. Entre em contato com o prestador para solicitar uma nova proposta.' });
    }

    const { decisao, quotePackageId } = req.body || {};
    if (decisao !== 'aprovado' && decisao !== 'recusado') {
      return json(res, 400, { error: "decisao deve ser 'aprovado' ou 'recusado'." });
    }

    const db = store.db();
    const pacotesDoOrcamento = db.quotePackages.filter((p) => p.quoteId === quote.id);

    let valorFinal = quote.valor;
    if (decisao === 'aprovado') {
      if (pacotesDoOrcamento.length > 0) {
        // Ponto 1 da correção: se há pacotes oferecidos, a escolha é obrigatória.
        if (!quotePackageId) {
          return json(res, 400, { error: 'Selecione um pacote para aceitar este orçamento.' });
        }
        const pkg = pacotesDoOrcamento.find((p) => p.id === Number(quotePackageId));
        if (!pkg) return json(res, 400, { error: 'Pacote inválido para este orçamento.' });
        quote.quotePackageId = pkg.id;
        valorFinal = pkg.preco;
      }
      // Se não há pacotes, a aprovação usa normalmente o valor do orçamento
      // (quote.valor) — comportamento já coberto pelo valor padrão acima.
    }

    quote.decidedStatus = decisao === 'aprovado' ? 'Aprovado' : 'Recusado';
    quote.decidedAt = Date.now();
    store.save();
    logEvent(quote.id, decisao === 'aprovado' ? 'aprovado' : 'recusado', { quotePackageId: quote.quotePackageId, valorFinal });

    json(res, 200, { status: quote.decidedStatus, valorFinal });
  });
}

module.exports = { register };
