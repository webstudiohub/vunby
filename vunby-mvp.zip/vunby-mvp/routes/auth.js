'use strict';
const crypto = require('crypto');
const { json } = require('../lib/http');
const { hashPassword, verifyPassword, hashToken, hashesMatch, getSession, setSessionCookie, clearSessionCookie } = require('../lib/auth');
const store = require('../lib/db');
const { normalizePhone } = require('../lib/phone');
const { checkRateLimit } = require('../lib/rateLimit');
const { requireNonEmptyString } = require('../lib/validate');

const IS_PRODUCTION = process.env.NODE_ENV === 'production';

// Janelas de rate limit — simples e generosas o bastante para não atrapalhar
// uso normal, mas suficientes para travar tentativas automatizadas em série
// (Ponto 2). Não é antifraude avançado, é só um freio básico.
const RL = {
  LOGIN: { max: 8, windowMs: 15 * 60 * 1000 },
  REGISTER: { max: 8, windowMs: 15 * 60 * 1000 },
  PHONE_CODE: { max: 5, windowMs: 15 * 60 * 1000 },
  PHONE_CONFIRM: { max: 8, windowMs: 15 * 60 * 1000 },
  PASSWORD_RESET_REQUEST: { max: 5, windowMs: 15 * 60 * 1000 },
  PASSWORD_RESET_CONFIRM: { max: 8, windowMs: 15 * 60 * 1000 },
  DELETE_ACCOUNT: { max: 5, windowMs: 15 * 60 * 1000 },
};

// Padrões: 15 min (código) e 30 min (link). O override por variável de
// ambiente existe só para os testes conseguirem validar a expiração de
// verdade sem esperar 15 minutos — em uso normal, não definir.
const PHONE_CODE_TTL_MS = Number(process.env.PHONE_CODE_TTL_MS) || 15 * 60 * 1000;
const PASSWORD_RESET_TTL_MS = Number(process.env.PASSWORD_RESET_TTL_MS) || 30 * 60 * 1000;

function requireAuth(req, res) {
  const session = getSession(req);
  if (!session) {
    json(res, 401, { error: 'Não autenticado.' });
    return null;
  }
  return session;
}

function generateCode6() {
  return String(crypto.randomInt(0, 1000000)).padStart(6, '0');
}

/**
 * Gera e "envia" um código de verificação de telefone para a conta.
 *
 * PONTO PENDENTE (sinalizado, não decidido em silêncio): não há, neste
 * ambiente, integração com um provedor real de SMS/WhatsApp para ENVIAR o
 * código — isso exige uma decisão de produto/fornecedor (Twilio, Zenvia,
 * WhatsApp Business API, etc.) e acesso de rede que este sandbox não tem.
 * Em desenvolvimento, o código volta na própria resposta da API
 * (`codigoDev`) para permitir testar o fluxo de ponta a ponta. Em produção
 * (NODE_ENV=production), `codigoDev` NUNCA é incluído — o código some na
 * resposta e precisa ser de fato entregue por um provedor real antes de ir
 * ao ar, ou o usuário nunca conseguirá verificar o telefone.
 */
function gerarCodigoVerificacao(account) {
  const db = store.db();
  const codigo = generateCode6();
  // Só o HASH do código vai para o banco. O valor utilizável existe apenas
  // em memória, aqui, durante esta chamada (para entrega ao usuário).
  // O hash é amarrado à conta (accountId) para que o mesmo código gerado
  // para duas contas diferentes nunca produza o mesmo hash.
  const registro = {
    id: store.nextId('phoneVerifications'),
    accountId: account.id,
    telefone: account.telefone,
    codigoHash: hashToken('phone-code', `${account.id}:${codigo}`),
    criadoEm: Date.now(),
    expiraEm: Date.now() + PHONE_CODE_TTL_MS,
    confirmadoEm: null,
  };
  db.phoneVerifications.push(registro);
  store.save();
  if (!IS_PRODUCTION) {
    // eslint-disable-next-line no-console
    console.log(`[DEV] Código de verificação para ${account.telefone}: ${codigo}`);
  }
  // Devolve o texto claro só para quem chamou (uso em dev / entrega); o
  // registro persistido não o contém.
  return { codigo };
}

function contaPublica(account) {
  return {
    id: account.id,
    nome: account.nome,
    empresa: account.empresa,
    email: account.email,
    telefone: account.telefone,
    telefoneVerificado: account.telefoneVerificado,
    trialConcedido: account.trialConcedido,
  };
}

function register(router) {
  // ---------- Cadastro ----------
  router.post('/api/auth/register', (req, res) => {
    checkRateLimit('register', req, RL.REGISTER);

    const { nome, empresa, email, senha, telefone, aceitouTermos } = req.body || {};
    if (!nome || !email || !senha || !telefone) {
      return json(res, 400, { error: 'Nome, e-mail, telefone e senha são obrigatórios.' });
    }
    requireNonEmptyString(nome, 'Nome');
    requireNonEmptyString(email, 'E-mail');
    if (String(senha).length < 6) {
      return json(res, 400, { error: 'A senha precisa ter pelo menos 6 caracteres.' });
    }
    // Ponto 5 — aceite dos Termos/Política é obrigatório para criar conta.
    if (aceitouTermos !== true) {
      return json(res, 400, { error: 'É necessário aceitar os Termos de Uso e a Política de Privacidade para criar sua conta.' });
    }
    const telefoneNormalizado = normalizePhone(telefone);
    if (telefoneNormalizado.length < 10) {
      return json(res, 400, { error: 'Informe um telefone válido com DDD.' });
    }

    const db = store.db();
    if (db.accounts.some((a) => a.email === email)) {
      return json(res, 409, { error: 'Este e-mail já está cadastrado.' });
    }

    const account = {
      id: store.nextId('accounts'),
      nome,
      empresa: empresa || '',
      email,
      senhaHash: hashPassword(senha),
      plano: 'gratuito',
      telefone: telefoneNormalizado,
      telefoneVerificado: false,
      // null = ainda não decidido (aguardando verificação); true/false depois.
      trialConcedido: null,
      aceitouTermosEm: Date.now(),
      createdAt: Date.now(),
    };
    db.accounts.push(account);
    store.save();

    const verificacao = gerarCodigoVerificacao(account);
    setSessionCookie(res, { accountId: account.id });

    const resposta = { ...contaPublica(account), verificacaoNecessaria: true };
    if (!IS_PRODUCTION) resposta.codigoDev = verificacao.codigo; // nunca em produção
    json(res, 201, resposta);
  });

  router.post('/api/auth/login', (req, res) => {
    checkRateLimit('login', req, RL.LOGIN);

    const { email, senha } = req.body || {};
    const db = store.db();
    const account = db.accounts.find((a) => a.email === email);
    if (!account || !verifyPassword(senha || '', account.senhaHash)) {
      return json(res, 401, { error: 'E-mail ou senha inválidos.' });
    }
    setSessionCookie(res, { accountId: account.id });
    json(res, 200, contaPublica(account));
  });

  router.post('/api/auth/logout', (req, res) => {
    clearSessionCookie(res);
    json(res, 200, { ok: true });
  });

  router.get('/api/auth/me', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const account = db.accounts.find((a) => a.id === session.accountId);
    if (!account) return json(res, 401, { error: 'Sessão inválida.' });
    json(res, 200, contaPublica(account));
  });

  // ---------- Verificação de telefone / controle de trial (Ponto 1) ----------
  router.post('/api/auth/phone/reenviar', (req, res) => {
    checkRateLimit('phone-code', req, RL.PHONE_CODE);
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const account = db.accounts.find((a) => a.id === session.accountId);
    if (!account) return json(res, 401, { error: 'Sessão inválida.' });
    if (account.telefoneVerificado) {
      return json(res, 400, { error: 'Este telefone já está verificado.' });
    }
    const verificacao = gerarCodigoVerificacao(account);
    const resposta = { ok: true };
    if (!IS_PRODUCTION) resposta.codigoDev = verificacao.codigo;
    json(res, 200, resposta);
  });

  router.post('/api/auth/phone/confirmar', (req, res) => {
    checkRateLimit('phone-confirm', req, RL.PHONE_CONFIRM);
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const account = db.accounts.find((a) => a.id === session.accountId);
    if (!account) return json(res, 401, { error: 'Sessão inválida.' });
    if (account.telefoneVerificado) {
      return json(res, 200, { telefoneVerificado: true, trialConcedido: account.trialConcedido });
    }

    const { codigo } = req.body || {};
    const now = Date.now();
    const pendente = db.phoneVerifications
      .filter((v) => v.accountId === account.id && !v.confirmadoEm && v.expiraEm > now)
      .sort((a, b) => b.criadoEm - a.criadoEm)[0];

    if (!pendente || !hashesMatch(pendente.codigoHash, hashToken('phone-code', `${account.id}:${String(codigo || '')}`))) {
      return json(res, 400, { error: 'Código inválido ou expirado.' });
    }

    pendente.confirmadoEm = now;
    account.telefoneVerificado = true;

    // Regra central do Ponto 1: o benefício do trial só é concedido se este
    // telefone (normalizado) NUNCA tiver sido usado para trial antes — e
    // essa lista é persistente e independente da conta, sobrevivendo à
    // exclusão dela (ver rota de exclusão de conta, mais abaixo).
    const jaUsado = db.verifiedTrialPhones.some((p) => p.telefone === account.telefone);
    if (jaUsado) {
      account.trialConcedido = false;
    } else {
      db.verifiedTrialPhones.push({
        telefone: account.telefone,
        primeiraContaId: account.id,
        verificadoEm: now,
      });
      account.trialConcedido = true;
    }
    store.save();

    json(res, 200, {
      telefoneVerificado: true,
      trialConcedido: account.trialConcedido,
      mensagem: account.trialConcedido
        ? 'Telefone verificado! Seu período de teste grátis foi liberado.'
        : 'Telefone verificado. Este número já foi usado para o teste grátis anteriormente, então esta conta não terá esse benefício.',
    });
  });

  // ---------- Recuperação de senha (Ponto 3) ----------
  router.post('/api/auth/recuperar-senha', (req, res) => {
    checkRateLimit('password-reset-request', req, RL.PASSWORD_RESET_REQUEST);
    const { email } = req.body || {};
    const db = store.db();
    const account = db.accounts.find((a) => a.email === email);

    // Resposta sempre igual, exista ou não a conta — não revela se um
    // e-mail está cadastrado (mesmo princípio do Ponto 1: não expor
    // informação sensível sobre a existência de outra conta).
    const resposta = { ok: true, mensagem: 'Se este e-mail existir em nossa base, enviaremos instruções de recuperação.' };

    if (account) {
      const token = crypto.randomBytes(24).toString('base64url');
      db.passwordResets.push({
        id: store.nextId('passwordResets'),
        accountId: account.id,
        // Só o HASH do token vai para o banco — o valor utilizável existe
        // apenas em memória nesta chamada (entrega/dev), nunca persistido.
        tokenHash: hashToken('password-reset', token),
        criadoEm: Date.now(),
        expiraEm: Date.now() + PASSWORD_RESET_TTL_MS,
        usadoEm: null,
      });
      store.save();
      if (!IS_PRODUCTION) {
        // eslint-disable-next-line no-console
        console.log(`[DEV] Link de recuperação para ${email}: /redefinir-senha.html?token=${token}`);
        resposta.tokenDev = token; // nunca em produção — ver nota abaixo
      }
    }
    // PONTO PENDENTE (mesma natureza do envio de SMS): não há, neste
    // ambiente, integração com um provedor real de e-mail para ENVIAR o
    // link de recuperação. Em produção isso precisa ir por e-mail de
    // verdade — sem isso, ninguém consegue recuperar a senha.
    json(res, 200, resposta);
  });

  router.post('/api/auth/redefinir-senha', (req, res) => {
    checkRateLimit('password-reset-confirm', req, RL.PASSWORD_RESET_CONFIRM);
    const { token, novaSenha } = req.body || {};
    if (!token || !novaSenha) return json(res, 400, { error: 'Token e nova senha são obrigatórios.' });
    if (String(novaSenha).length < 6) return json(res, 400, { error: 'A senha precisa ter pelo menos 6 caracteres.' });

    const db = store.db();
    const now = Date.now();
    const tokenHash = hashToken('password-reset', String(token));
    const reset = db.passwordResets.find((r) => hashesMatch(r.tokenHash, tokenHash) && !r.usadoEm && r.expiraEm > now);
    if (!reset) return json(res, 400, { error: 'Link inválido ou expirado.' });

    const account = db.accounts.find((a) => a.id === reset.accountId);
    if (!account) return json(res, 400, { error: 'Link inválido ou expirado.' });

    account.senhaHash = hashPassword(novaSenha);
    // Uso único: invalida este token e qualquer outro link de recuperação
    // ainda pendente desta conta (senão um link antigo, pedido antes,
    // poderia redefinir a senha de novo depois desta troca).
    db.passwordResets
      .filter((r) => r.accountId === account.id && !r.usadoEm)
      .forEach((r) => { r.usadoEm = now; });
    store.save();
    json(res, 200, { ok: true });
  });

  // ---------- Exclusão de conta (Ponto 4) ----------
  router.post('/api/auth/excluir-conta', (req, res) => {
    checkRateLimit('delete-account', req, RL.DELETE_ACCOUNT);
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const account = db.accounts.find((a) => a.id === session.accountId);
    if (!account) return json(res, 401, { error: 'Sessão inválida.' });

    const { senha } = req.body || {};
    if (!verifyPassword(senha || '', account.senhaHash)) {
      return json(res, 401, { error: 'Senha incorreta.' });
    }

    // Remove SÓ a conta. NUNCA tocar em verifiedTrialPhones aqui — esse é
    // justamente o registro que precisa sobreviver à exclusão da conta
    // para impedir que o mesmo telefone receba outro trial depois.
    db.accounts = db.accounts.filter((a) => a.id !== account.id);
    store.save();
    clearSessionCookie(res);
    json(res, 200, { ok: true });
  });
}

module.exports = { register, requireAuth };
