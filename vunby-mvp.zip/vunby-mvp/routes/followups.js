'use strict';
const { json } = require('../lib/http');
const store = require('../lib/db');
const { requireAuth } = require('./auth');
const { logEvent } = require('./quotes');
const cfg = require('../lib/config');

function register(router) {
  router.post('/api/quotes/:id/followups', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const quote = db.quotes.find((q) => q.id === Number(req.params.id) && q.accountId === session.accountId);
    if (!quote) return json(res, 404, { error: 'Orçamento não encontrado.' });

    const { mensagem } = req.body || {};
    const client = db.clients.find((c) => c.id === quote.clientId);

    const followUp = {
      id: store.nextId('followUps'),
      quoteId: quote.id,
      createdAt: Date.now(),
      mensagem: mensagem || `Olá, ${client ? client.nome : ''}! Passando para saber se conseguiu ver o orçamento que te enviei.`,
      // Nunca "entregue" ou "lido" — só o que a VUNBY de fato sabe fazer: preparar e o usuário confirmar.
      estado: 'preparado',
    };
    db.followUps.push(followUp);
    store.save();
    logEvent(quote.id, 'follow_up_registrado', { followUpId: followUp.id });

    const link = `${cfg.BASE_URL}/orcamento.html?token=${quote.publicToken}`;
    const texto = encodeURIComponent(`${followUp.mensagem} ${link}`);
    const whatsappLink = client ? `https://wa.me/${client.telefone.replace(/\D/g, '')}?text=${texto}` : null;

    // Nota: registramos aqui como "preparado" no momento da criação; o
    // front pode chamar /confirmar depois que o usuário efetivamente abrir
    // o WhatsApp, mas o MVP não pode e não deve afirmar entrega/leitura.
    json(res, 201, { followUp, whatsappLink });
  });

  router.post('/api/quotes/:id/followups/:followUpId/confirmar', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const quote = db.quotes.find((q) => q.id === Number(req.params.id) && q.accountId === session.accountId);
    if (!quote) return json(res, 404, { error: 'Orçamento não encontrado.' });
    const fu = db.followUps.find((f) => f.id === Number(req.params.followUpId) && f.quoteId === quote.id);
    if (!fu) return json(res, 404, { error: 'Follow-up não encontrado.' });
    fu.estado = 'confirmado_pelo_usuario'; // nunca "entregue"/"lido"
    store.save();
    json(res, 200, fu);
  });

  router.get('/api/quotes/:id/followups', (req, res) => {
    const session = requireAuth(req, res);
    if (!session) return;
    const db = store.db();
    const quote = db.quotes.find((q) => q.id === Number(req.params.id) && q.accountId === session.accountId);
    if (!quote) return json(res, 404, { error: 'Orçamento não encontrado.' });
    json(res, 200, db.followUps.filter((f) => f.quoteId === quote.id).sort((a, b) => b.createdAt - a.createdAt));
  });
}

module.exports = { register };
