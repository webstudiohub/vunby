const { chromium } = require('playwright');
const assert = require('assert');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  // --- Setup: conta + pacote + orçamento com nome malicioso ---
  await page.goto('http://localhost:3000/index.html');
  await page.click('#toggle-link');
  await page.fill('#reg-nome', 'João');
  await page.fill('#reg-empresa', 'João Eletricista');
  await page.fill('#reg-email', 'xss-test@teste.com');
  await page.fill('#reg-telefone', '11977776666');
  await page.fill('#reg-senha', '123456');
  await page.check('#reg-termos');
  await page.click('#submit-register');
  await page.waitForURL('**/verificar-telefone.html');
  await page.goto('http://localhost:3000/dashboard.html');

  await page.goto('http://localhost:3000/pacotes.html');
  await page.fill('#p-nome', 'Completo');
  await page.fill('#p-conteudo', 'Equipe completa');
  await page.fill('#p-preco', '1000');
  await page.click('text=Salvar modelo');
  await page.waitForTimeout(400);

  const NOME_MALICIOSO = '<img src=x onerror="window.__xss=true">';
  const SERVICO_MALICIOSO = '<script>window.__xss2=true</script>Mudança';

  await page.goto('http://localhost:3000/novo-orcamento.html');
  await page.fill('#r-nome', NOME_MALICIOSO);
  await page.fill('#r-telefone', '11988887777');
  await page.fill('#r-servico', SERVICO_MALICIOSO);
  await page.fill('#r-valor', '1000');
  await page.selectOption('#r-pacote', { index: 1 });
  await page.click('#btn-gerar-rapido');
  await page.waitForSelector('text=Orçamento gerado!');
  const link = await page.getAttribute('#r-resultado a', 'href');

  // --- TESTE 1: XSS não executa em nenhuma tela que mostra esse orçamento ---
  await page.evaluate(() => { window.__xss = false; window.__xss2 = false; });
  await page.goto('http://localhost:3000/dashboard.html');
  await page.waitForTimeout(300);
  let xssFired = await page.evaluate(() => window.__xss || window.__xss2);
  assert.notStrictEqual(xssFired, true, 'FALHA: payload XSS executou no Dashboard!');
  const dashboardText = await page.textContent('body');
  assert.ok(dashboardText.includes('<img'), 'FALHA: nome malicioso não aparece como texto literal no Dashboard (deveria aparecer escapado)');
  console.log('OK: Dashboard escapa XSS corretamente.');

  await page.goto('http://localhost:3000/historico.html');
  await page.waitForTimeout(300);
  xssFired = await page.evaluate(() => window.__xss || window.__xss2);
  assert.notStrictEqual(xssFired, true, 'FALHA: payload XSS executou no Histórico!');
  console.log('OK: Histórico escapa XSS corretamente.');

  await page.goto('http://localhost:3000/radar.html');
  await page.waitForTimeout(300);
  xssFired = await page.evaluate(() => window.__xss || window.__xss2);
  assert.notStrictEqual(xssFired, true, 'FALHA: payload XSS executou no Radar!');
  console.log('OK: Radar escapa XSS corretamente.');

  // Pega o id do orçamento pelo dashboard para checar a tela de detalhe
  // Descobre o ID real do orçamento perguntando à própria API — nunca
  // assumir que será 1, mesmo que neste teste só exista um orçamento até
  // aqui (a suíte deve continuar correta se isso mudar no futuro).
  const tokenCriado = new URL(link, 'http://localhost:3000').searchParams.get('token');
  const listaOrcamentos = await page.evaluate(() =>
    fetch('/api/quotes', { credentials: 'include' }).then((r) => r.json())
  );
  const orcamentoCriado = listaOrcamentos.find((q) => q.publicToken === tokenCriado);
  assert.ok(orcamentoCriado, 'FALHA: não encontrei na API o orçamento recém-criado pelo token público.');
  const quoteId = orcamentoCriado.id;
  await page.goto(`http://localhost:3000/orcamento-detalhe.html?id=${quoteId}`);
  await page.waitForTimeout(300);
  xssFired = await page.evaluate(() => window.__xss || window.__xss2);
  assert.notStrictEqual(xssFired, true, 'FALHA: payload XSS executou na tela de detalhe!');
  console.log('OK: Tela de detalhe escapa XSS corretamente.');

  // Página pública (cliente) — não usa app.js, tem esc() próprio
  const clientPage = await browser.newPage();
  await clientPage.evaluate(() => { window.__xss = false; window.__xss2 = false; }).catch(() => {});
  await clientPage.goto('http://localhost:3000' + link);
  await clientPage.waitForTimeout(300);
  xssFired = await clientPage.evaluate(() => window.__xss || window.__xss2);
  assert.notStrictEqual(xssFired, true, 'FALHA: payload XSS executou na página pública!');
  console.log('OK: Página pública escapa XSS corretamente.');

  // --- TESTE 2: botão Aceitar começa desabilitado quando há pacotes ---
  const disabledAntes = await clientPage.getAttribute('#btn-aceitar', 'disabled');
  assert.notStrictEqual(disabledAntes, null, 'FALHA: botão Aceitar deveria começar desabilitado quando há pacotes.');
  console.log('OK: botão Aceitar começa desabilitado sem pacote escolhido.');

  await clientPage.check('input[name="pacote"]');
  const disabledDepois = await clientPage.getAttribute('#btn-aceitar', 'disabled');
  assert.strictEqual(disabledDepois, null, 'FALHA: botão Aceitar deveria habilitar após escolher um pacote.');
  console.log('OK: botão Aceitar habilita após escolher um pacote.');
  await clientPage.close();

  // --- TESTE 3: fluxo de confirmação de follow-up ---
  await page.goto(`http://localhost:3000/orcamento-detalhe.html?id=${quoteId}`);
  await page.waitForTimeout(300);
  const [popup] = await Promise.all([
    page.waitForEvent('popup').catch(() => null),
    page.click('text=1. Preparar e abrir WhatsApp'),
  ]);
  if (popup) await popup.close();
  await page.waitForTimeout(300);
  const temBotaoConfirmar = await page.isVisible('text=Confirmar que enviei pelo WhatsApp');
  assert.ok(temBotaoConfirmar, 'FALHA: botão de confirmação de follow-up não apareceu.');
  console.log('OK: botão de confirmação de follow-up aparece após preparar.');

  await page.click('text=Confirmar que enviei pelo WhatsApp');
  await page.waitForTimeout(300);
  // Checa especificamente o texto do próprio registro de follow-up (não a
  // página inteira — o parágrafo explicativo cita "entregue/lido" de propósito
  // para dizer que a VUNBY NÃO afirma isso, o que é o comportamento correto).
  const textoRegistro = await page.textContent('h3:has-text("Histórico de follow-ups") ~ *, .container');
  const secaoHistorico = (await page.$('div.card:has-text("Histórico de follow-ups")').then((h) => h.textContent()));
  assert.ok(secaoHistorico.includes('confirmado pelo usuário'), 'FALHA: estado do follow-up não mudou para confirmado.');
  assert.ok(!/\bentregue\b/i.test(secaoHistorico) && !/\blido\b/i.test(secaoHistorico), 'FALHA: o registro do follow-up em si afirma entrega/leitura, o que a spec proíbe.');
  console.log('OK: follow-up confirmado pelo usuário, sem afirmar entrega/leitura no registro.');

  await browser.close();
  console.log('\n=== TODOS OS TESTES DE REGRESSÃO PASSARAM ===');
})().catch((err) => {
  console.error('FALHA NO TESTE:', err.message);
  process.exit(1);
});
